# Nexus Finance: publicação e backend seguro

O repositório GitHub continua sendo a origem do código, mas **GitHub Pages não executa Python nem PostgreSQL**. A configuração [render.yaml](../render.yaml) publica o site e a API juntos como um único serviço Python no Render; os dados ficam num PostgreSQL gerenciado externo (por exemplo, Neon). Assim o navegador acessa UI e API pela mesma origem HTTPS, e a sessão usa cookie `HttpOnly`, `Secure` e `SameSite=Lax`, sem depender de cookies de terceiros.

Nenhuma configuração torna segredos impossíveis de descobrir: o código do repositório é público e o provedor que executa o backend precisa receber a credencial do banco. A proteção é manter essa credencial **somente nas variáveis secretas do provedor**, nunca no HTML/JavaScript, no GitHub, neste chat ou em capturas de tela. O provedor de hospedagem e o de banco ainda precisam ser confiáveis. Planos gratuitos têm limites e não garantem disponibilidade.

## Publicar usando o GitHub como origem

1. Envie o projeto ao seu repositório GitHub. O código-fonte do backend será público por escolha, mas não contém a senha do PostgreSQL.
2. Crie uma instância PostgreSQL num provedor gerenciado. Copie a URI de conexão com TLS habilitado (`sslmode=require`).
3. No Render, crie um Blueprint a partir do repositório e use o arquivo `render.yaml`. Ao solicitar `DATABASE_URL`, informe a URI do banco como segredo do serviço. Não a grave num arquivo do projeto.
4. Depois do deploy, abra o endereço HTTPS fornecido pelo Render. O mesmo serviço apresenta o site e a API; ele executa as migrações versionadas na inicialização. O frontend detecta a própria origem automaticamente.
5. Desative GitHub Pages para este app se não for mais usado. O site servido pelo Render é implantado automaticamente a partir do repositório.

O serviço serve apenas uma lista fixa de arquivos públicos (`index.html`, `app.js`, `site-structure.js`, `styles.css` e `manifest.json`); não expõe as pastas Python, migrações ou arquivos de configuração por HTTP. `/api/health` é uma verificação pública de disponibilidade e **não** devolve dados do banco.

## Segredos e limites operacionais

- `DATABASE_URL` é segredo de ambiente no Render; use uma URI TLS do banco e nunca um valor de exemplo com senha real no Git.
- `SESSION_COOKIE_SECURE=true` fica ativo em produção. O cookie contém um token opaco; o banco armazena somente o hash do token.
- CORS permite a origem externa exata que o Render fornece ao serviço (`RENDER_EXTERNAL_URL`) e nenhuma origem curinga. Configure origens adicionais somente se necessárias.
- Senhas são armazenadas como hashes PBKDF2-HMAC-SHA256 com salt individual; movimentações e metas pertencem a uma conta e as consultas são isoladas pelo usuário autenticado.
- A inscrição é aberta. Use uma senha única e longa. O servidor pequeno não fornece MFA, recuperação de senha, limitação distribuída de tentativas ou proteção contra indisponibilidade; não trate um plano gratuito como infraestrutura bancária ou garantia de disponibilidade.
- O provedor do backend consegue acessar suas variáveis de ambiente; o provedor do banco opera a infraestrutura. Dados ainda podem ser expostos por uma conta de provedor comprometida, erro no app, dispositivo inseguro ou captura de tela.
- Os registros antigos do `localStorage` e linhas de banco sem proprietário não são importados para uma conta automaticamente. Permanecem separados até uma importação verificada.

## Rodar localmente

Instale Python 3.10+ e PostgreSQL. No PowerShell, a partir da raiz do projeto:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r backend\requirements.txt
$env:DATABASE_URL = "postgresql://USUARIO:SENHA@localhost:5432/nexus_finance"
$env:CORS_ALLOWED_ORIGINS = "http://localhost:8000"
$env:SESSION_COOKIE_SECURE = "false"
python -m backend.migrate
python -m backend.server
```

Abra `http://localhost:8000`. **Substitua USUARIO e SENHA apenas no terminal local**; não envie a URI para o chat. O mesmo servidor Python local publica a interface e responde à API.

O Render recebe `PORT` automaticamente. `HOST` é `0.0.0.0`. `SESSION_TTL_DAYS` pode ajustar a validade da sessão (padrão: 30 dias). `CORS_ALLOWED_ORIGINS` é uma lista separada por vírgulas de origens exatas, sem caminhos; o Render adiciona sua própria origem automaticamente.

As migrações `001_initial.sql` e `002_accounts_sessions_and_ownership.sql` são ordenadas e registradas em `schema_migrations`; reaplicar é seguro. Linhas existentes sem `user_id` são mantidas, mas não ficam visíveis para nenhuma conta.

## Autenticação e API

O cadastro é aberto: qualquer pessoa pode criar uma conta com e-mail válido e senha de 12 a 1024 caracteres. O e-mail é normalizado em minúsculas; a senha nunca é armazenada em texto puro. Sessões opacas expiram por padrão após 30 dias e logout revoga a sessão no servidor. O cookie é `HttpOnly`, `Secure` e `SameSite=Lax` em produção. Não há wildcard de CORS. Dados financeiros só são acessíveis com sessão e todas as consultas são limitadas ao ID da conta autenticada.

| Método e rota | Operação |
| --- | --- |
| `POST /api/auth/register` | Cadastro com `{ "email": "...", "password": "..." }` |
| `POST /api/auth/login` | Login com e-mail e senha; define cookie da sessão |
| `GET /api/auth/me` | Confere a sessão |
| `POST /api/auth/logout` | Revoga a sessão |
| `GET/POST /api/transactions` | Lista/cria movimentações |
| `GET/PUT/PATCH/DELETE /api/transactions/{id}` | Lê, altera ou remove movimentação |
| `PATCH /api/transactions/{id}/pay` | Marca compromisso como pago |
| `GET/POST /api/goals` | Lista/cria metas |
| `PUT/PATCH/DELETE /api/goals/{id}` | Altera ou remove meta |
| `GET /api/health` | Health check público, sem dados pessoais |

## Validação

```powershell
python -m unittest discover -s backend\tests -t .
python -m compileall -q backend
```
