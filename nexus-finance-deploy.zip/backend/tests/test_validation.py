import unittest
from datetime import date
from decimal import Decimal
from unittest.mock import patch

from backend.server import (
    ApiError,
    NexusHandler,
    STATIC_ASSETS,
    hash_password,
    normalize_email,
    session_digest,
    transaction_json,
    validate_goal,
    validate_password,
    validate_transaction,
    verify_password,
)


class ValidationTests(unittest.TestCase):
    def test_transaction_uses_app_fields_and_defaults(self):
        values = validate_transaction({
            "date": "2026-10-07",
            "description": "Conta de luz",
            "amount": "128.90",
            "currentInstallment": 2,
            "paidAt": "",
        })
        self.assertEqual(values["date"], date(2026, 10, 7))
        self.assertEqual(values["amount"], Decimal("128.90"))
        self.assertEqual(values["type"], "Saída")
        self.assertEqual(values["currentInstallment"], 2)
        self.assertIsNone(values["paidAt"])

    def test_partial_update_allows_independent_fields(self):
        self.assertEqual(validate_transaction({"status": "Pago"}, partial=True), {"status": "Pago"})

    def test_rejects_invalid_amount_and_date(self):
        for body in (
            {"date": "2026-10-07", "description": "Conta", "amount": -2},
            {"date": "not-a-date", "description": "Conta", "amount": 10},
            {"date": "20261007", "description": "Conta", "amount": 10},
            {"date": "2026-10-07", "description": "Conta", "amount": 2.345},
        ):
            with self.subTest(body=body), self.assertRaises(ApiError):
                validate_transaction(body)

    def test_transaction_response_matches_apps_script_shape(self):
        data = {
            "id": 12, "date": date(2026, 10, 7), "type": "Saída", "description": "Conta",
            "category": "Casa", "subcategory": "", "purpose": "", "classification": "Controlável",
            "amount": Decimal("12.50"), "status": "Pago", "note": "", "mode": "Compromisso",
            "installments": 1, "current_installment": 1, "due_day": 7, "recurrence": "Mensal",
            "priority": "", "paid_at": date(2026, 10, 7),
        }
        result = transaction_json(data)
        self.assertEqual(result["month"], "Outubro")
        self.assertEqual(result["year"], 2026)
        self.assertEqual(result["currentInstallment"], 1)
        self.assertEqual(result["paidAt"], "2026-10-07")

    def test_goal_fields_match_existing_form(self):
        values = validate_goal({"name": "Reserva", "target": 1000, "current": "50", "date": ""})
        self.assertEqual(values["name"], "Reserva")
        self.assertEqual(values["target"], Decimal("1000"))
        self.assertIsNone(values["date"])
        with self.assertRaises(ApiError):
            validate_goal({"name": "Reserva", "target": 0})

    def test_passwords_are_salted_hashed_and_verifiable(self):
        first = hash_password("a-long-enough-passphrase", salt=b"0123456789abcdef", iterations=100_000)
        second = hash_password("a-long-enough-passphrase", salt=b"fedcba9876543210", iterations=100_000)
        self.assertNotEqual(first, second)
        self.assertTrue(verify_password("a-long-enough-passphrase", first))
        self.assertFalse(verify_password("wrong-password", first))
        self.assertNotIn("a-long-enough-passphrase", first)

    def test_account_input_normalization_and_bounds(self):
        self.assertEqual(normalize_email("  Example@Mail.com "), "example@mail.com")
        with self.assertRaises(ApiError):
            normalize_email("not-an-email")
        self.assertEqual(validate_password("twelve-chars!"), "twelve-chars!")
        for password in ("short", "x" * 1025):
            with self.subTest(password_length=len(password)), self.assertRaises(ApiError):
                validate_password(password)

    def test_session_cookie_tokens_are_stored_as_digests(self):
        raw = "random-opaque-cookie-token"
        digest = session_digest(raw)
        self.assertNotEqual(raw, digest)
        self.assertEqual(len(digest), 64)

    def test_cors_requires_explicit_exact_origins(self):
        with patch.dict("os.environ", {"CORS_ALLOWED_ORIGINS": "https://finance.example"}):
            self.assertTrue(NexusHandler._origin_allowed("https://finance.example"))
            self.assertFalse(NexusHandler._origin_allowed("https://finance.example.attacker.test"))
            self.assertFalse(NexusHandler._origin_allowed("https://owner.github.io"))

    def test_cookie_is_http_only_secure_and_same_site_by_default(self):
        with patch.dict("os.environ", {"SESSION_COOKIE_SECURE": "true"}):
            cookie = NexusHandler._cookie_header("opaque-token", max_age=3600)
        self.assertIn("HttpOnly", cookie)
        self.assertIn("Secure", cookie)
        self.assertIn("SameSite=Lax", cookie)
        self.assertNotIn("SameSite=None", cookie)
        self.assertIn("Max-Age=3600", cookie)

    def test_render_external_url_is_a_single_exact_allowed_origin(self):
        with patch.dict("os.environ", {"RENDER_EXTERNAL_URL": "https://nexus-finance.onrender.com",
                                       "CORS_ALLOWED_ORIGINS": ""}):
            self.assertTrue(NexusHandler._origin_allowed("https://nexus-finance.onrender.com"))
            self.assertFalse(NexusHandler._origin_allowed("https://attacker.onrender.com"))

    def test_only_allowlisted_static_assets_are_exposed(self):
        self.assertIn("/", STATIC_ASSETS)
        self.assertNotIn("/backend/server.py", STATIC_ASSETS)

    def test_transaction_pay_endpoint_uses_patch_route_and_account_scope(self):
        handler = NexusHandler.__new__(NexusHandler)
        with patch.object(handler, "_mark_paid") as mark_paid:
            handler._dispatch("PATCH", "/api/transactions/31/pay", {}, {}, user_id=8)
        mark_paid.assert_called_once_with("31", 8)

    def test_previous_mark_paid_route_is_not_exposed(self):
        handler = NexusHandler.__new__(NexusHandler)
        with self.assertRaises(ApiError) as raised:
            handler._dispatch("POST", "/api/transactions/31/mark-paid", {}, {}, user_id=8)
        self.assertEqual(raised.exception.status, 404)


if __name__ == "__main__":
    unittest.main()
